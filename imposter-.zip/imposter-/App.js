// ═══════════════════════════════════════════════════
//  IMPOSTER — Who's Lying?
//  React Native app for Expo
//  Offline multiplayer over hotspot (WebRTC / UDP)
// ═══════════════════════════════════════════════════

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, StatusBar, Animated, Alert, Clipboard,
  Vibration, BackHandler, Platform,
} from 'react-native';

// ── Colours ──────────────────────────────────────────
const C = {
  bg:      '#0a0a0f',
  surface: '#12121a',
  card:    '#1a1a26',
  border:  '#2a2a3f',
  accent:  '#ff3a3a',
  accent2: '#ff8c00',
  safe:    '#00e5a0',
  text:    '#e8e8f0',
  muted:   '#6b6b8a',
};

// ═══════════════════════════════════════════════════
//  WORD LIBRARY — edit words here
// ═══════════════════════════════════════════════════
const WORDS = {
  food: [
    { crew:'PIZZA', imp:'LASAGNA' }, { crew:'SUSHI', imp:'SASHIMI' },
    { crew:'BURGER', imp:'SANDWICH' }, { crew:'COFFEE', imp:'ESPRESSO' },
    { crew:'CHOCOLATE', imp:'COCOA' }, { crew:'PASTA', imp:'NOODLES' },
    { crew:'ICE CREAM', imp:'GELATO' }, { crew:'WINE', imp:'CHAMPAGNE' },
    { crew:'TACOS', imp:'BURRITOS' }, { crew:'PANCAKES', imp:'WAFFLES' },
    { crew:'STEAK', imp:'LAMB CHOP' }, { crew:'SOUP', imp:'STEW' },
    { crew:'BREAD', imp:'BAGUETTE' }, { crew:'CAKE', imp:'MUFFIN' },
    { crew:'DONUT', imp:'BAGEL' }, { crew:'RAMEN', imp:'PHO' },
    { crew:'CURRY', imp:'STIR FRY' }, { crew:'FRIED RICE', imp:'BIRYANI' },
    { crew:'NACHOS', imp:'CHIPS & DIP' }, { crew:'MILKSHAKE', imp:'SMOOTHIE' },
    { crew:'BEER', imp:'CIDER' }, { crew:'WHISKEY', imp:'BOURBON' },
    { crew:'TEA', imp:'HERBAL TEA' }, { crew:'KEBAB', imp:'SHAWARMA' },
    { crew:'POPCORN', imp:'PRINGLES' }, { crew:'CHEESECAKE', imp:'TIRAMISU' },
  ],
  animals: [
    { crew:'LION', imp:'CHEETAH' }, { crew:'SHARK', imp:'DOLPHIN' },
    { crew:'EAGLE', imp:'HAWK' }, { crew:'ELEPHANT', imp:'RHINO' },
    { crew:'WOLF', imp:'COYOTE' }, { crew:'GORILLA', imp:'CHIMPANZEE' },
    { crew:'PENGUIN', imp:'PUFFIN' }, { crew:'CROCODILE', imp:'ALLIGATOR' },
    { crew:'TIGER', imp:'LEOPARD' }, { crew:'BEAR', imp:'PANDA' },
    { crew:'GIRAFFE', imp:'CAMEL' }, { crew:'PARROT', imp:'TOUCAN' },
    { crew:'COBRA', imp:'PYTHON' }, { crew:'FROG', imp:'TOAD' },
    { crew:'RABBIT', imp:'HARE' }, { crew:'OCTOPUS', imp:'SQUID' },
    { crew:'BUTTERFLY', imp:'MOTH' }, { crew:'BEE', imp:'WASP' },
    { crew:'OWL', imp:'FALCON' }, { crew:'FLAMINGO', imp:'CRANE' },
    { crew:'KANGAROO', imp:'WALLABY' }, { crew:'HIPPO', imp:'MANATEE' },
  ],
  places: [
    { crew:'PARIS', imp:'BRUSSELS' }, { crew:'BEACH', imp:'COAST' },
    { crew:'FOREST', imp:'JUNGLE' }, { crew:'MUSEUM', imp:'GALLERY' },
    { crew:'AIRPORT', imp:'TRAIN STATION' }, { crew:'HOSPITAL', imp:'CLINIC' },
    { crew:'CASINO', imp:'ARCADE' }, { crew:'STADIUM', imp:'ARENA' },
    { crew:'NEW YORK', imp:'CHICAGO' }, { crew:'TOKYO', imp:'OSAKA' },
    { crew:'LONDON', imp:'MANCHESTER' }, { crew:'DUBAI', imp:'ABU DHABI' },
    { crew:'ROME', imp:'MILAN' }, { crew:'DESERT', imp:'SAVANNA' },
    { crew:'MOUNTAIN', imp:'HILL' }, { crew:'RIVER', imp:'LAKE' },
    { crew:'LIBRARY', imp:'BOOKSTORE' }, { crew:'SCHOOL', imp:'UNIVERSITY' },
    { crew:'PALACE', imp:'CASTLE' }, { crew:'MARKET', imp:'BAZAAR' },
  ],
  sports: [
    { crew:'FOOTBALL', imp:'RUGBY' }, { crew:'TENNIS', imp:'BADMINTON' },
    { crew:'SWIMMING', imp:'DIVING' }, { crew:'BOXING', imp:'MMA' },
    { crew:'BASKETBALL', imp:'VOLLEYBALL' }, { crew:'GOLF', imp:'POLO' },
    { crew:'CYCLING', imp:'TRIATHLON' }, { crew:'SKIING', imp:'SNOWBOARDING' },
    { crew:'CRICKET', imp:'BASEBALL' }, { crew:'HOCKEY', imp:'LACROSSE' },
    { crew:'WRESTLING', imp:'JUDO' }, { crew:'SURFING', imp:'WAKEBOARDING' },
    { crew:'KARATE', imp:'TAEKWONDO' }, { crew:'MARATHON', imp:'SPRINT' },
    { crew:'SNOOKER', imp:'BILLIARDS' }, { crew:'TABLE TENNIS', imp:'SQUASH' },
    { crew:'SKATEBOARDING', imp:'ROLLERBLADING' }, { crew:'WEIGHTLIFTING', imp:'POWERLIFTING' },
    { crew:'CURLING', imp:'BOWLING' }, { crew:'MOTOCROSS', imp:'BMX' },
  ],
  movies: [
    { crew:'COMEDY', imp:'SITCOM' }, { crew:'HORROR', imp:'THRILLER' },
    { crew:'MUSICAL', imp:'OPERA' }, { crew:'DOCUMENTARY', imp:'MOCKUMENTARY' },
    { crew:'ANIMATION', imp:'ANIME' }, { crew:'SCI-FI', imp:'FANTASY' },
    { crew:'SUPERHERO', imp:'ACTION' }, { crew:'ROMANCE', imp:'DRAMA' },
    { crew:'HEIST', imp:'SPY FILM' }, { crew:'ZOMBIE', imp:'VAMPIRE FILM' },
    { crew:'BIOPIC', imp:'DOCUDRAMA' }, { crew:'REALITY TV', imp:'GAME SHOW' },
    { crew:'NETFLIX SERIES', imp:'HBO SHOW' }, { crew:'CARTOON', imp:'ANIME' },
    { crew:'REBOOT', imp:'SPINOFF' }, { crew:'BOX OFFICE HIT', imp:'CULT CLASSIC' },
  ],
  music: [
    { crew:'GUITAR', imp:'BASS GUITAR' }, { crew:'PIANO', imp:'KEYBOARD' },
    { crew:'DRUMS', imp:'BONGOS' }, { crew:'VIOLIN', imp:'VIOLA' },
    { crew:'HIP HOP', imp:'RAP' }, { crew:'ROCK', imp:'METAL' },
    { crew:'POP', imp:'R&B' }, { crew:'JAZZ', imp:'BLUES' },
    { crew:'EDM', imp:'TECHNO' }, { crew:'REGGAE', imp:'DANCEHALL' },
    { crew:'COUNTRY', imp:'FOLK' }, { crew:'PUNK', imp:'GRUNGE' },
    { crew:'DISCO', imp:'FUNK' }, { crew:'SOUL', imp:'GOSPEL' },
    { crew:'CONCERT', imp:'FESTIVAL' }, { crew:'REMIX', imp:'COVER' },
  ],
  technology: [
    { crew:'IPHONE', imp:'ANDROID' }, { crew:'LAPTOP', imp:'TABLET' },
    { crew:'WIFI', imp:'BLUETOOTH' }, { crew:'INSTAGRAM', imp:'SNAPCHAT' },
    { crew:'YOUTUBE', imp:'TIKTOK' }, { crew:'WHATSAPP', imp:'TELEGRAM' },
    { crew:'NETFLIX', imp:'PRIME VIDEO' }, { crew:'PLAYSTATION', imp:'XBOX' },
    { crew:'AI', imp:'MACHINE LEARNING' }, { crew:'ROBOT', imp:'DRONE' },
    { crew:'VR HEADSET', imp:'AR GLASSES' }, { crew:'SMARTWATCH', imp:'FITNESS TRACKER' },
    { crew:'HACKER', imp:'PROGRAMMER' }, { crew:'MEME', imp:'GIF' },
    { crew:'PODCAST', imp:'AUDIOBOOK' }, { crew:'CHATGPT', imp:'GEMINI' },
  ],
  gaming: [
    { crew:'MINECRAFT', imp:'ROBLOX' }, { crew:'FORTNITE', imp:'PUBG' },
    { crew:'FIFA', imp:'PES' }, { crew:'GTA', imp:'RED DEAD REDEMPTION' },
    { crew:'CALL OF DUTY', imp:'BATTLEFIELD' }, { crew:'MARIO', imp:'SONIC' },
    { crew:'ZELDA', imp:'POKEMON' }, { crew:'AMONG US', imp:'SECRET HITLER' },
    { crew:'CHESS', imp:'CHECKERS' }, { crew:'MONOPOLY', imp:'CATAN' },
    { crew:'UNO', imp:'SKIP-BO' }, { crew:'ESPORTS', imp:'GAMING TOURNAMENT' },
    { crew:'BOSS FIGHT', imp:'FINAL LEVEL' }, { crew:'LOOT BOX', imp:'BATTLE PASS' },
    { crew:'RPG', imp:'MMORPG' }, { crew:'FPS', imp:'TPS' },
  ],
  nature: [
    { crew:'THUNDER', imp:'LIGHTNING' }, { crew:'TORNADO', imp:'HURRICANE' },
    { crew:'EARTHQUAKE', imp:'TSUNAMI' }, { crew:'RAINBOW', imp:'AURORA' },
    { crew:'CLOUD', imp:'FOG' }, { crew:'SUNRISE', imp:'SUNSET' },
    { crew:'FULL MOON', imp:'ECLIPSE' }, { crew:'ROSE', imp:'TULIP' },
    { crew:'CACTUS', imp:'SUCCULENT' }, { crew:'CORAL REEF', imp:'SEAWEED' },
    { crew:'GLACIER', imp:'ICEBERG' }, { crew:'CLIFF', imp:'CANYON' },
    { crew:'FIRE', imp:'LAVA' }, { crew:'RAIN', imp:'DRIZZLE' },
    { crew:'SNOW', imp:'SLEET' }, { crew:'DIAMOND', imp:'RUBY' },
  ],
  random: [
    { crew:'COMPASS', imp:'GPS' }, { crew:'TELESCOPE', imp:'BINOCULARS' },
    { crew:'PIRATE', imp:'SAILOR' }, { crew:'THRONE', imp:'CHAIR' },
    { crew:'ROCKET', imp:'MISSILE' }, { crew:'TREASURE', imp:'LOOT' },
    { crew:'SWORD', imp:'DAGGER' }, { crew:'CROWN', imp:'TIARA' },
    { crew:'DRAGON', imp:'WYVERN' }, { crew:'UNICORN', imp:'PEGASUS' },
    { crew:'TIME MACHINE', imp:'PORTAL' }, { crew:'LABYRINTH', imp:'MAZE' },
    { crew:'ORACLE', imp:'PROPHET' }, { crew:'LEGEND', imp:'MYTH' },
    { crew:'MAGIC WAND', imp:'STAFF' }, { crew:'POTION', imp:'ELIXIR' },
  ],
};

const CATEGORIES = [
  { key:'food',       emoji:'🍕', label:'Food & Drink' },
  { key:'animals',    emoji:'🐾', label:'Animals' },
  { key:'places',     emoji:'🌍', label:'Places' },
  { key:'sports',     emoji:'⚽', label:'Sports' },
  { key:'movies',     emoji:'🎬', label:'Movies & Shows' },
  { key:'music',      emoji:'🎵', label:'Music' },
  { key:'technology', emoji:'📱', label:'Technology' },
  { key:'gaming',     emoji:'🎮', label:'Gaming' },
  { key:'nature',     emoji:'🌿', label:'Nature' },
  { key:'random',     emoji:'🎲', label:'Random Mix' },
];

// ═══════════════════════════════════════════════════
//  NETWORKING — UDP broadcast over LAN using
//  react-native-udp (available in bare Expo)
//  For Expo Go / Snack we use a polling fallback
//  via AsyncStorage shared state simulation.
//
//  On bare Expo (built APK) install:
//  expo install react-native-udp
// ═══════════════════════════════════════════════════

// Simple in-memory message bus (works when all players
// are on same device for testing, replaced by UDP in APK)
let _bus = {};
let _busListeners = {};
function busPost(room, msg) {
  if (!_bus[room]) _bus[room] = [];
  _bus[room].push({ ...msg, _t: Date.now() });
  if (_busListeners[room]) _busListeners[room].forEach(fn => fn(msg));
}
function busListen(room, fn) {
  if (!_busListeners[room]) _busListeners[room] = [];
  _busListeners[room].push(fn);
  return () => { _busListeners[room] = _busListeners[room].filter(f => f !== fn); };
}

// ═══════════════════════════════════════════════════
//  HELPERS
// ═══════════════════════════════════════════════════
function genId() { return Math.random().toString(36).substr(2, 8).toUpperCase(); }
function genRoom() { return Math.random().toString(36).substr(2, 6).toUpperCase(); }
function getRandPair(cat) {
  const arr = WORDS[cat] || WORDS.random;
  return arr[Math.floor(Math.random() * arr.length)];
}

// ═══════════════════════════════════════════════════
//  REUSABLE UI COMPONENTS
// ═══════════════════════════════════════════════════

function Btn({ label, onPress, type = 'primary', disabled, style }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const onPressIn = () => Animated.spring(scaleAnim, { toValue: 0.96, useNativeDriver: true }).start();
  const onPressOut = () => Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true }).start();
  const bg = type === 'primary' ? C.accent : type === 'safe' ? C.safe : type === 'warn' ? C.accent2 : C.surface;
  const color = type === 'safe' ? '#0a0a0f' : C.text;
  return (
    <Animated.View style={[{ transform: [{ scale: scaleAnim }] }, style]}>
      <TouchableOpacity
        onPress={onPress} onPressIn={onPressIn} onPressOut={onPressOut}
        disabled={disabled}
        style={[styles.btn, { backgroundColor: bg, opacity: disabled ? 0.4 : 1 }]}
        activeOpacity={0.85}
      >
        <Text style={[styles.btnText, { color }]}>{label}</Text>
      </TouchableOpacity>
    </Animated.View>
  );
}

function Card({ children, style }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

function CardTitle({ children }) {
  return <Text style={styles.cardTitle}>{children}</Text>;
}

function StatusBar2({ connected, text }) {
  return (
    <View style={styles.statusBar}>
      <View style={[styles.statusDot, { backgroundColor: connected ? C.safe : C.muted }]} />
      <Text style={styles.statusText}>{text}</Text>
    </View>
  );
}

function PlayerItem({ name, isHost, badge, badgeType }) {
  return (
    <View style={[styles.playerItem, isHost && styles.playerItemHost]}>
      <Text style={styles.playerName}>{name}</Text>
      <View style={[styles.badge, badgeType === 'ready' && styles.badgeReady]}>
        <Text style={[styles.badgeText, badgeType === 'ready' && styles.badgeTextReady]}>
          {badge}
        </Text>
      </View>
    </View>
  );
}

function Toast({ message, type, visible }) {
  const opacity = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (visible) {
      Animated.sequence([
        Animated.timing(opacity, { toValue: 1, duration: 200, useNativeDriver: true }),
        Animated.delay(2000),
        Animated.timing(opacity, { toValue: 0, duration: 300, useNativeDriver: true }),
      ]).start();
    }
  }, [visible, message]);
  const bg = type === 'success' ? C.safe : type === 'error' ? C.accent : C.accent2;
  return (
    <Animated.View style={[styles.toast, { opacity, borderColor: bg }]}>
      <Text style={[styles.toastText, { color: bg }]}>{message}</Text>
    </Animated.View>
  );
}

// ═══════════════════════════════════════════════════
//  MAIN APP
// ═══════════════════════════════════════════════════
export default function App() {
  const [screen, setScreen] = useState('home');
  const [myName, setMyName] = useState('');
  const [myId] = useState(() => genId());
  const [isHost, setIsHost] = useState(false);
  const [roomCode, setRoomCode] = useState('');
  const [roomInput, setRoomInput] = useState('');
  const [players, setPlayers] = useState([]);
  const [category, setCategory] = useState('food');
  const [catIndex, setCatIndex] = useState(0);
  const [discussSecs, setDiscussSecs] = useState(120);
  const [myRole, setMyRole] = useState('crewmate');
  const [myWord, setMyWord] = useState('');
  const [wordRevealed, setWordRevealed] = useState(false);
  const [timeLeft, setTimeLeft] = useState(120);
  const [votes, setVotes] = useState({});
  const [myVote, setMyVote] = useState(null);
  const [voteConfirmed, setVoteConfirmed] = useState(false);
  const [gameState, setGameState] = useState({});
  const [toast, setToast] = useState({ msg: '', type: 'info', v: false });
  const [lobbyLog, setLobbyLog] = useState([]);
  const [connStatus, setConnStatus] = useState('Not connected');
  const [connected, setConnected] = useState(false);
  const timerRef = useRef(null);
  const unlistenRef = useRef(null);

  // ── Toast helper ──
  const showToast = useCallback((msg, type = 'info') => {
    setToast({ msg, type, v: true });
    setTimeout(() => setToast(t => ({ ...t, v: false })), 2800);
  }, []);

  const addLog = useCallback((from, msg) => {
    setLobbyLog(l => [...l.slice(-20), { from, msg, id: Date.now() }]);
  }, []);

  // ── Back button ──
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (screen !== 'home') { goHome(); return true; }
      return false;
    });
    return () => sub.remove();
  }, [screen]);

  // ── Cleanup on unmount ──
  useEffect(() => () => { if (timerRef.current) clearInterval(timerRef.current); }, []);

  // ─────────────────────────────────────────────────
  //  NETWORKING (in-memory bus for Snack/Expo Go,
  //  replace with UDP for production APK)
  // ─────────────────────────────────────────────────
  function startListening(room) {
    if (unlistenRef.current) unlistenRef.current();
    unlistenRef.current = busListen(room, (data) => handleMessage(data));
  }

  function broadcast(msg) { busPost(roomCode, { ...msg, from: myId }); }
  function sendToHost(msg) { busPost(roomCode, { ...msg, from: myId, toHost: true }); }

  function handleMessage(data) {
    if (data.from === myId) return; // ignore own messages
    switch (data.type) {
      case 'JOIN_REQUEST':
        if (isHost) {
          setPlayers(prev => {
            if (prev.find(p => p.id === data.id)) return prev;
            const next = [...prev, { id: data.id, name: data.name, isHost: false }];
            busPost(roomCode, { type: 'PLAYER_LIST', players: next, from: myId });
            addLog('System', data.name + ' joined!');
            return next;
          });
        }
        break;
      case 'PLAYER_LIST':
        setPlayers(data.players);
        break;
      case 'GAME_START':
        receiveStart(data);
        break;
      case 'PLAYER_READY':
        if (isHost) {
          setGameState(gs => {
            const ready = new Set(gs.readyPlayers || []);
            ready.add(data.from);
            const next = { ...gs, readyPlayers: ready };
            setPlayers(p => {
              if (ready.size >= p.length) {
                busPost(roomCode, { type: 'ALL_READY', from: myId });
                startDiscussion(next.totalSecs || 120, next.myWord || '');
              }
              return p;
            });
            return next;
          });
        }
        break;
      case 'ALL_READY':
        setGameState(gs => { startDiscussion(gs.totalSecs || 120, gs.myWord || ''); return gs; });
        break;
      case 'VOTE_CAST':
        if (isHost) {
          setVotes(v => {
            const next = { ...v, [data.from]: data.target };
            busPost(roomCode, { type: 'VOTE_UPDATE', votes: next, from: myId });
            setPlayers(p => { checkAllVoted(next, p, data.imposterIndex || 0, data.wordPair); return p; });
            return next;
          });
        }
        break;
      case 'VOTE_UPDATE':
        setVotes(data.votes);
        break;
      case 'GAME_RESULT':
        showResult(data);
        break;
      case 'PLAY_AGAIN':
        resetLobby();
        break;
    }
  }

  // ─────────────────────────────────────────────────
  //  HOME SCREEN ACTIONS
  // ─────────────────────────────────────────────────
  function createRoom() {
    if (!myName.trim()) { showToast('Enter your name first!', 'error'); return; }
    const code = genRoom();
    setRoomCode(code);
    setIsHost(true);
    setPlayers([{ id: myId, name: myName.trim(), isHost: true }]);
    setConnStatus('Hosting · ' + code);
    setConnected(true);
    setLobbyLog([]);
    startListening(code);
    addLog('System', 'Room created: ' + code);
    addLog('System', 'Share code with friends on same hotspot');
    setScreen('lobby');
  }

  function joinRoom() {
    if (!myName.trim()) { showToast('Enter your name first!', 'error'); return; }
    if (!roomInput.trim()) { showToast('Enter room code!', 'error'); return; }
    const code = roomInput.trim().toUpperCase();
    setRoomCode(code);
    setIsHost(false);
    setConnStatus('Joining ' + code + '...');
    startListening(code);
    busPost(code, { type: 'JOIN_REQUEST', id: myId, name: myName.trim(), from: myId });
    setConnected(true);
    setConnStatus('Connected to ' + code);
    showToast('Joined room ' + code, 'success');
    setScreen('guestLobby');
  }

  // ─────────────────────────────────────────────────
  //  GAME START
  // ─────────────────────────────────────────────────
  function startGame() {
    const pair = getRandPair(category);
    const impIdx = Math.floor(Math.random() * players.length);
    players.forEach((p, i) => {
      const role = i === impIdx ? 'imposter' : 'crewmate';
      const word = role === 'imposter' ? pair.imp : pair.crew;
      busPost(roomCode, {
        type: 'GAME_START', from: myId, targetId: p.id,
        role, word, wordPair: pair, imposterIndex: impIdx,
        players, discussSecs,
      });
    });
  }

  function receiveStart(data) {
    if (data.targetId !== myId) return;
    setMyRole(data.role);
    setMyWord(data.word);
    setWordRevealed(false);
    setPlayers(data.players || players);
    setGameState({
      wordPair: data.wordPair, imposterIndex: data.imposterIndex,
      totalSecs: data.discussSecs, myWord: data.word,
      readyPlayers: new Set(),
    });
    setVotes({});
    setMyVote(null);
    setVoteConfirmed(false);
    setScreen('word');
  }

  // ─────────────────────────────────────────────────
  //  READY & DISCUSSION
  // ─────────────────────────────────────────────────
  function playerReady() {
    if (isHost) {
      setGameState(gs => {
        const ready = new Set(gs.readyPlayers || []);
        ready.add(myId);
        if (ready.size >= players.length) {
          broadcast({ type: 'ALL_READY' });
          startDiscussion(gs.totalSecs || 120, gs.myWord || myWord);
        }
        return { ...gs, readyPlayers: ready };
      });
    } else {
      sendToHost({ type: 'PLAYER_READY' });
    }
    setScreen('waiting');
  }

  function startDiscussion(totalSecs, word) {
    if (timerRef.current) clearInterval(timerRef.current);
    const secs = totalSecs || discussSecs;
    setTimeLeft(secs);
    setScreen('discuss');
    let t = secs;
    timerRef.current = setInterval(() => {
      t--;
      setTimeLeft(t);
      if (t <= 0) { clearInterval(timerRef.current); startVoting(); }
    }, 1000);
  }

  // ─────────────────────────────────────────────────
  //  VOTING
  // ─────────────────────────────────────────────────
  function startVoting() {
    if (timerRef.current) clearInterval(timerRef.current);
    setMyVote(null);
    setVoteConfirmed(false);
    setVotes({});
    setScreen('vote');
  }

  function confirmVote() {
    if (!myVote) return;
    setVoteConfirmed(true);
    Vibration.vibrate(30);
    if (isHost) {
      setVotes(v => {
        const next = { ...v, [myId]: myVote };
        broadcast({ type: 'VOTE_UPDATE', votes: next });
        checkAllVoted(next, players, gameState.imposterIndex, gameState.wordPair);
        return next;
      });
    } else {
      sendToHost({ type: 'VOTE_CAST', target: myVote,
        imposterIndex: gameState.imposterIndex, wordPair: gameState.wordPair });
    }
  }

  function checkAllVoted(v, p, impIdx, wordPair) {
    if (Object.keys(v).length >= p.length) resolveVotes(v, p, impIdx, wordPair);
  }

  function resolveVotes(v, p, impIdx, wordPair) {
    const tally = {};
    Object.values(v).forEach(id => { tally[id] = (tally[id] || 0) + 1; });
    let max = 0, votedOut = null;
    Object.entries(tally).forEach(([id, c]) => { if (c > max) { max = c; votedOut = id; } });
    const imposter = p[impIdx];
    const impWins = votedOut !== imposter?.id;
    const result = { type: 'GAME_RESULT', imposterWins: impWins, votedOutId: votedOut,
      imposterIndex: impIdx, wordPair, votes: v, players: p, from: myId };
    broadcast(result);
    showResult(result);
  }

  function showResult(data) {
    if (timerRef.current) clearInterval(timerRef.current);
    setGameState(gs => ({ ...gs, result: data }));
    setPlayers(data.players || players);
    setScreen('result');
    Vibration.vibrate([0, 100, 50, 100]);
  }

  // ─────────────────────────────────────────────────
  //  PLAY AGAIN / HOME
  // ─────────────────────────────────────────────────
  function playAgain() {
    broadcast({ type: 'PLAY_AGAIN' });
    resetLobby();
  }

  function resetLobby() {
    if (timerRef.current) clearInterval(timerRef.current);
    setVotes({});
    setMyVote(null);
    setVoteConfirmed(false);
    setLobbyLog([]);
    setScreen(isHost ? 'lobby' : 'guestLobby');
  }

  function goHome() {
    if (timerRef.current) clearInterval(timerRef.current);
    if (unlistenRef.current) unlistenRef.current();
    setScreen('home');
    setPlayers([]);
    setRoomCode('');
    setRoomInput('');
    setConnected(false);
    setConnStatus('Not connected');
    setIsHost(false);
    setVotes({});
    setLobbyLog([]);
    setGameState({});
  }

  // ─────────────────────────────────────────────────
  //  CATEGORY PICKER
  // ─────────────────────────────────────────────────
  function nextCat() {
    const i = (catIndex + 1) % CATEGORIES.length;
    setCatIndex(i);
    setCategory(CATEGORIES[i].key);
  }
  function prevCat() {
    const i = (catIndex - 1 + CATEGORIES.length) % CATEGORIES.length;
    setCatIndex(i);
    setCategory(CATEGORIES[i].key);
  }

  // ─────────────────────────────────────────────────
  //  TIMER DISPLAY
  // ─────────────────────────────────────────────────
  const timerMins = Math.floor(timeLeft / 60);
  const timerSecs = timeLeft % 60;
  const timerStr = timerMins + ':' + String(timerSecs).padStart(2, '0');
  const totalSecs = gameState.totalSecs || discussSecs;
  const timerPct = Math.max(0, timeLeft / totalSecs);
  const timerColor = timeLeft <= 30 ? C.accent : timeLeft <= totalSecs * 0.5 ? C.accent2 : C.safe;

  // ── Vote tally ──
  const tally = {};
  Object.values(votes).forEach(id => { tally[id] = (tally[id] || 0) + 1; });

  // ─────────────────────────────────────────────────
  //  RENDER
  // ─────────────────────────────────────────────────
  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <Toast message={toast.msg} type={toast.type} visible={toast.v} />

      {/* ══ HOME ══ */}
      {screen === 'home' && (
        <ScrollView contentContainerStyle={styles.screen}>
          <View style={styles.logo}>
            <Text style={styles.logoTitle}>IMPOSTER</Text>
            <Text style={styles.logoSub}>WHO'S LYING?</Text>
          </View>
          <View style={styles.offlineBadge}>
            <View style={[styles.statusDot, { backgroundColor: C.safe }]} />
            <Text style={styles.offlineBadgeText}>OFFLINE · HOTSPOT PLAY</Text>
          </View>
          <Card>
            <CardTitle>YOUR NAME</CardTitle>
            <TextInput
              style={styles.input}
              placeholder="Enter your name..."
              placeholderTextColor={C.muted}
              value={myName}
              onChangeText={setMyName}
              maxLength={16}
              autoCorrect={false}
            />
          </Card>
          <Card>
            <CardTitle>MULTIPLAYER — HOTSPOT</CardTitle>
            <Text style={styles.lanInfo}>
              📡 One person turns on <Text style={{ color: C.safe }}>Android Hotspot</Text>.{'\n'}
              Everyone connects to that WiFi.{'\n'}
              Host taps HOST GAME — guests tap JOIN GAME.{'\n'}
              <Text style={{ color: C.safe }}>Zero internet needed! ✅</Text>
            </Text>
            <View style={styles.row}>
              <Btn label="HOST GAME" onPress={createRoom} type="primary" style={{ flex: 1 }} />
              <View style={{ width: 10 }} />
              <Btn label="JOIN GAME" onPress={() => setScreen('join')} type="secondary" style={{ flex: 1 }} />
            </View>
          </Card>
          <StatusBar2 connected={connected} text={connStatus} />
        </ScrollView>
      )}

      {/* ══ JOIN ══ */}
      {screen === 'join' && (
        <ScrollView contentContainerStyle={styles.screen}>
          <View style={styles.logo}>
            <Text style={styles.logoTitle}>JOIN</Text>
            <Text style={styles.logoSub}>ENTER ROOM CODE</Text>
          </View>
          <Card>
            <CardTitle>ROOM CODE</CardTitle>
            <TextInput
              style={[styles.input, { fontSize: 28, letterSpacing: 8, textAlign: 'center' }]}
              placeholder="ABC123"
              placeholderTextColor={C.muted}
              value={roomInput}
              onChangeText={t => setRoomInput(t.toUpperCase())}
              maxLength={6}
              autoCapitalize="characters"
              autoCorrect={false}
            />
          </Card>
          <Btn label="JOIN ROOM" onPress={joinRoom} type="safe" />
          <Btn label="BACK" onPress={() => setScreen('home')} type="secondary" />
        </ScrollView>
      )}

      {/* ══ HOST LOBBY ══ */}
      {screen === 'lobby' && (
        <ScrollView contentContainerStyle={styles.screen}>
          <View style={styles.logo}>
            <Text style={styles.logoTitle}>LOBBY</Text>
            <Text style={styles.logoSub}>WAITING FOR PLAYERS</Text>
          </View>
          <Card>
            <CardTitle>ROOM CODE</CardTitle>
            <TouchableOpacity onPress={() => { Clipboard.setString(roomCode); showToast('Code copied!', 'success'); }}>
              <View style={styles.roomCode}>
                <Text style={styles.roomCodeText}>{roomCode}</Text>
                <Text style={styles.roomCodeHint}>tap to copy · share with friends on same hotspot</Text>
              </View>
            </TouchableOpacity>
          </Card>
          <Card>
            <CardTitle>PLAYERS ({players.length})</CardTitle>
            {players.map(p => (
              <PlayerItem key={p.id} name={p.name} isHost={p.isHost}
                badge={p.isHost ? 'HOST' : 'JOINED'} badgeType={p.isHost ? 'host' : 'ready'} />
            ))}
          </Card>
          <Card>
            <CardTitle>CATEGORY</CardTitle>
            <View style={styles.catPicker}>
              <TouchableOpacity onPress={prevCat} style={styles.catBtn}>
                <Text style={styles.catBtnText}>‹</Text>
              </TouchableOpacity>
              <Text style={styles.catLabel}>
                {CATEGORIES[catIndex].emoji} {CATEGORIES[catIndex].label}
              </Text>
              <TouchableOpacity onPress={nextCat} style={styles.catBtn}>
                <Text style={styles.catBtnText}>›</Text>
              </TouchableOpacity>
            </View>
          </Card>
          <Card>
            <CardTitle>DISCUSSION TIME</CardTitle>
            <View style={styles.catPicker}>
              <TouchableOpacity onPress={() => setDiscussSecs(s => Math.max(30, s - 30))} style={styles.catBtn}>
                <Text style={styles.catBtnText}>−</Text>
              </TouchableOpacity>
              <Text style={styles.catLabel}>
                {Math.floor(discussSecs/60)}:{String(discussSecs%60).padStart(2,'0')}
              </Text>
              <TouchableOpacity onPress={() => setDiscussSecs(s => Math.min(600, s + 30))} style={styles.catBtn}>
                <Text style={styles.catBtnText}>+</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.row} style={{ marginTop: 8 }}>
              {[60,120,180,300].map(s => (
                <TouchableOpacity key={s} onPress={() => setDiscussSecs(s)}
                  style={[styles.presetBtn, discussSecs === s && styles.presetBtnActive]}>
                  <Text style={[styles.presetBtnText, discussSecs === s && { color: C.accent2 }]}>
                    {s/60}min
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </Card>
          {lobbyLog.length > 0 && (
            <Card>
              <CardTitle>ACTIVITY LOG</CardTitle>
              {lobbyLog.slice(-5).map(l => (
                <Text key={l.id} style={styles.logEntry}><Text style={{ color: C.text }}>[{l.from}]</Text> {l.msg}</Text>
              ))}
            </Card>
          )}
          <Btn label={players.length < 2 ? 'NEED 2+ PLAYERS' : 'START GAME'}
            onPress={startGame} type="primary" disabled={players.length < 2} />
          <Btn label="LEAVE" onPress={goHome} type="secondary" />
        </ScrollView>
      )}

      {/* ══ GUEST LOBBY ══ */}
      {screen === 'guestLobby' && (
        <ScrollView contentContainerStyle={styles.screen}>
          <View style={styles.logo}>
            <Text style={styles.logoTitle}>JOINED</Text>
            <Text style={styles.logoSub}>WAITING FOR HOST</Text>
          </View>
          <Card>
            <CardTitle>ROOM</CardTitle>
            <View style={styles.roomCode}>
              <Text style={styles.roomCodeText}>{roomCode}</Text>
            </View>
          </Card>
          <Card>
            <CardTitle>PLAYERS ({players.length})</CardTitle>
            {players.map(p => (
              <PlayerItem key={p.id} name={p.name} isHost={p.isHost}
                badge={p.isHost ? 'HOST' : 'JOINED'} badgeType={p.isHost ? 'host' : 'ready'} />
            ))}
          </Card>
          <View style={styles.waiting}>
            <Text style={styles.waitingText}>Waiting for host to start...</Text>
          </View>
          <Btn label="LEAVE" onPress={goHome} type="secondary" />
        </ScrollView>
      )}

      {/* ══ WORD REVEAL ══ */}
      {screen === 'word' && (
        <ScrollView contentContainerStyle={styles.screen}>
          <View style={styles.logo}>
            <Text style={styles.logoTitle}>YOUR WORD</Text>
            <Text style={styles.logoSub}>KEEP IT SECRET</Text>
          </View>
          <Card>
            <View style={styles.wordReveal}>
              <View style={[styles.roleBadge, myRole === 'imposter' ? styles.roleBadgeImp : styles.roleBadgeCrew]}>
                <Text style={[styles.roleBadgeText, { color: myRole === 'imposter' ? C.accent : C.safe }]}>
                  {myRole === 'imposter' ? '🔪 IMPOSTER' : '✅ CREWMATE'}
                </Text>
              </View>
              <TouchableOpacity onPress={() => setWordRevealed(r => !r)} style={styles.wordBox}>
                <Text style={[styles.wordText,
                  { color: myRole === 'imposter' ? C.accent : C.safe },
                  !wordRevealed && styles.wordBlurred
                ]}>
                  {myWord}
                </Text>
              </TouchableOpacity>
              <Text style={styles.tapHint}>TAP TO {wordRevealed ? 'HIDE' : 'REVEAL'} YOUR WORD</Text>
            </View>
          </Card>
          <Card>
            <Text style={[styles.small, { textAlign: 'center', lineHeight: 22 }]}>
              <Text style={{ color: C.text, fontWeight: 'bold' }}>Crewmates</Text>
              <Text> share a </Text>
              <Text style={{ color: C.accent2 }}>specific word</Text>
              <Text>. The </Text>
              <Text style={{ color: C.accent }}>Imposter</Text>
              <Text> gets a </Text>
              <Text style={{ color: C.accent2 }}>similar but different word</Text>
              <Text>. Give clues without saying your word!</Text>
            </Text>
          </Card>
          <Btn label="I'M READY" onPress={playerReady} type="safe" />
        </ScrollView>
      )}

      {/* ══ WAITING ══ */}
      {screen === 'waiting' && (
        <View style={[styles.screen, { justifyContent: 'center', alignItems: 'center' }]}>
          <Text style={styles.logoTitle}>WAITING</Text>
          <Text style={[styles.small, { marginTop: 16, textAlign: 'center' }]}>
            Waiting for all players to be ready...
          </Text>
        </View>
      )}

      {/* ══ DISCUSSION ══ */}
      {screen === 'discuss' && (
        <ScrollView contentContainerStyle={styles.screen}>
          <View style={styles.logo}>
            <Text style={styles.logoTitle}>DISCUSS</Text>
            <Text style={styles.logoSub}>FIND THE IMPOSTER</Text>
          </View>
          <Card>
            <CardTitle>TIME REMAINING</CardTitle>
            <Text style={[styles.timerText, { color: timerColor }, timeLeft <= 30 && styles.timerWarning]}>
              {timerStr}
            </Text>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: `${timerPct * 100}%`, backgroundColor: timerColor }]} />
            </View>
          </Card>
          <Card>
            <Text style={[styles.small, { textAlign: 'center', lineHeight: 22 }]}>
              Give hints about your word{' '}
              <Text style={{ color: C.accent2 }}>without saying it</Text>.{'\n'}
              Figure out who doesn't quite fit in.{'\n\n'}
              <Text style={{ color: C.text, fontWeight: 'bold' }}>Your word: </Text>
              <Text style={{ color: C.accent2 }}>{myWord}</Text>
            </Text>
          </Card>
          <Card>
            <CardTitle>PLAYERS</CardTitle>
            {players.map(p => (
              <PlayerItem key={p.id} name={p.name + (p.id === myId ? ' (you)' : '')}
                isHost={p.isHost} badge={p.isHost ? 'HOST' : '●'} badgeType="ready" />
            ))}
          </Card>
        </ScrollView>
      )}

      {/* ══ VOTING ══ */}
      {screen === 'vote' && (
        <ScrollView contentContainerStyle={styles.screen}>
          <View style={styles.logo}>
            <Text style={styles.logoTitle}>VOTE</Text>
            <Text style={styles.logoSub}>WHO'S THE IMPOSTER?</Text>
          </View>
          <Card>
            <CardTitle>CAST YOUR VOTE</CardTitle>
            {players.map(p => {
              const isMe = p.id === myId;
              const voteCount = tally[p.id] || 0;
              return (
                <TouchableOpacity key={p.id} disabled={isMe || voteConfirmed}
                  onPress={() => setMyVote(p.id)}
                  style={[styles.voteBtn, myVote === p.id && styles.voteBtnSelected, isMe && { opacity: 0.4 }]}>
                  <Text style={styles.voteBtnText}>{p.name}{isMe ? ' (you)' : ''}</Text>
                  {voteCount > 0 && <Text style={styles.voteCount}>{'🔴'.repeat(Math.min(voteCount,5))} {voteCount}</Text>}
                </TouchableOpacity>
              );
            })}
          </Card>
          <Card>
            <Text style={[styles.small, { textAlign:'center' }]}>
              {Object.keys(votes).length} / {players.length} players voted
            </Text>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: `${(Object.keys(votes).length / Math.max(1, players.length)) * 100}%`, backgroundColor: C.accent }]} />
            </View>
          </Card>
          {!voteConfirmed
            ? <Btn label="CONFIRM VOTE" onPress={confirmVote} type="primary" disabled={!myVote} />
            : <View style={styles.waiting}><Text style={styles.waitingText}>Waiting for all votes...</Text></View>
          }
        </ScrollView>
      )}

      {/* ══ RESULTS ══ */}
      {screen === 'result' && gameState.result && (() => {
        const r = gameState.result;
        const imposter = (r.players || players)[r.imposterIndex];
        const rtally = {};
        Object.values(r.votes || {}).forEach(id => { rtally[id] = (rtally[id] || 0) + 1; });
        return (
          <ScrollView contentContainerStyle={styles.screen}>
            <View style={[styles.resultTop]}>
              <Text style={styles.resultEmoji}>{r.imposterWins ? '🔪' : '🎉'}</Text>
              <Text style={[styles.resultTitle, { color: r.imposterWins ? C.accent : C.safe }]}>
                {r.imposterWins ? 'IMPOSTER WINS' : 'CREW WINS!'}
              </Text>
              <Text style={styles.resultSubtitle}>
                {r.imposterWins ? 'The crew failed to find the imposter' : 'The imposter was caught!'}
              </Text>
            </View>
            <Card>
              <Text style={styles.small}>THE IMPOSTER WAS</Text>
              <Text style={[styles.imposterName]}>{imposter?.name || '?'}</Text>
              <View style={styles.wordPair}>
                <View style={styles.wordPillCrew}><Text style={{ color: C.safe, fontSize: 13 }}>Crew: {r.wordPair?.crew}</Text></View>
                <View style={styles.wordPillImp}><Text style={{ color: C.accent, fontSize: 13 }}>Imp: {r.wordPair?.imp}</Text></View>
              </View>
            </Card>
            <Card>
              <CardTitle>VOTES</CardTitle>
              {(r.players || players).map(p => {
                const c = rtally[p.id] || 0;
                const isImp = p.id === imposter?.id;
                return (
                  <PlayerItem key={p.id} name={p.name + (isImp ? ' 🔪' : '')}
                    isHost={isImp} badge={c + ' vote' + (c !== 1 ? 's' : '')}
                    badgeType={c > 0 ? 'host' : 'ready'} />
                );
              })}
            </Card>
            <View style={styles.row}>
              <Btn label="PLAY AGAIN" onPress={playAgain} type="primary" style={{ flex: 1 }} />
              <View style={{ width: 10 }} />
              <Btn label="HOME" onPress={goHome} type="secondary" style={{ flex: 1 }} />
            </View>
          </ScrollView>
        );
      })()}
    </View>
  );
}

// ═══════════════════════════════════════════════════
//  STYLES
// ═══════════════════════════════════════════════════
const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  screen: { padding: 20, paddingTop: 48, paddingBottom: 40, gap: 16 },

  logo: { alignItems: 'center', paddingVertical: 8 },
  logoTitle: {
    fontSize: 56, fontWeight: '900', letterSpacing: 4, color: C.accent,
    textShadowColor: 'rgba(255,58,58,0.4)', textShadowRadius: 20,
  },
  logoSub: { fontSize: 11, letterSpacing: 4, color: C.muted, marginTop: 2 },

  offlineBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    alignSelf: 'center', backgroundColor: 'rgba(0,229,160,0.08)',
    borderWidth: 1, borderColor: 'rgba(0,229,160,0.2)',
    borderRadius: 20, paddingHorizontal: 12, paddingVertical: 4,
  },
  offlineBadgeText: { fontSize: 10, letterSpacing: 2, color: C.safe },

  card: {
    backgroundColor: C.card, borderWidth: 1, borderColor: C.border,
    borderRadius: 12, padding: 16, gap: 10,
  },
  cardTitle: {
    fontSize: 11, fontWeight: '700', letterSpacing: 3,
    color: C.muted, textTransform: 'uppercase',
  },

  input: {
    backgroundColor: C.surface, borderWidth: 1, borderColor: C.border,
    borderRadius: 8, padding: 12, color: C.text, fontSize: 14,
  },

  btn: { borderRadius: 8, padding: 14, alignItems: 'center' },
  btnText: { fontSize: 17, fontWeight: '900', letterSpacing: 2 },

  statusBar: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: C.surface, borderWidth: 1, borderColor: C.border,
    borderRadius: 8, padding: 10,
  },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  statusText: { fontSize: 12, color: C.muted },

  lanInfo: { fontSize: 12, color: C.muted, lineHeight: 20 },

  row: { flexDirection: 'row', gap: 10 },

  playerItem: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: C.surface, borderWidth: 1, borderColor: C.border,
    borderRadius: 8, padding: 10, marginBottom: 6,
  },
  playerItemHost: { borderColor: 'rgba(255,140,0,0.4)' },
  playerName: { color: C.text, fontSize: 13 },
  badge: {
    backgroundColor: 'rgba(255,140,0,0.15)', borderRadius: 4,
    paddingHorizontal: 8, paddingVertical: 3,
  },
  badgeReady: { backgroundColor: 'rgba(0,229,160,0.15)' },
  badgeText: { fontSize: 10, letterSpacing: 1, color: C.accent2 },
  badgeTextReady: { color: C.safe },

  roomCode: {
    backgroundColor: C.surface, borderWidth: 1, borderColor: C.border,
    borderStyle: 'dashed', borderRadius: 8, padding: 16, alignItems: 'center',
  },
  roomCodeText: {
    fontSize: 44, fontWeight: '900', letterSpacing: 10, color: C.accent2,
  },
  roomCodeHint: { fontSize: 10, letterSpacing: 1, color: C.muted, marginTop: 4 },

  catPicker: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: C.surface, borderWidth: 1, borderColor: C.border,
    borderRadius: 8, overflow: 'hidden',
  },
  catBtn: { padding: 12, paddingHorizontal: 20 },
  catBtnText: { fontSize: 24, color: C.accent2, fontWeight: 'bold' },
  catLabel: { flex: 1, textAlign: 'center', color: C.accent2, fontSize: 15, fontWeight: '700' },

  presetBtn: {
    flex: 1, padding: 6, backgroundColor: C.surface,
    borderWidth: 1, borderColor: C.border, borderRadius: 6, alignItems: 'center',
  },
  presetBtnActive: { borderColor: C.accent2, backgroundColor: 'rgba(255,140,0,0.1)' },
  presetBtnText: { fontSize: 11, color: C.muted },

  logEntry: { fontSize: 11, color: C.muted, paddingVertical: 2 },

  wordReveal: { alignItems: 'center', paddingVertical: 16 },
  roleBadge: {
    borderRadius: 20, paddingHorizontal: 16, paddingVertical: 6,
    borderWidth: 1, marginBottom: 20,
  },
  roleBadgeImp: { backgroundColor: 'rgba(255,58,58,0.15)', borderColor: 'rgba(255,58,58,0.3)' },
  roleBadgeCrew: { backgroundColor: 'rgba(0,229,160,0.15)', borderColor: 'rgba(0,229,160,0.3)' },
  roleBadgeText: { fontSize: 13, fontWeight: '700', letterSpacing: 3 },
  wordBox: { paddingVertical: 10 },
  wordText: { fontSize: 48, fontWeight: '900', letterSpacing: 3 },
  wordBlurred: { opacity: 0.05 },
  tapHint: { fontSize: 10, letterSpacing: 2, color: C.muted, marginTop: 12 },

  waiting: { alignItems: 'center', padding: 16 },
  waitingText: { fontSize: 12, color: C.muted, letterSpacing: 1 },

  timerText: { fontSize: 52, fontWeight: '900', letterSpacing: 4, textAlign: 'center' },
  timerWarning: { opacity: 0.6 },
  progressBar: {
    height: 4, backgroundColor: C.border, borderRadius: 2,
    overflow: 'hidden', marginTop: 8,
  },
  progressFill: { height: '100%', borderRadius: 2 },

  small: { fontSize: 12, color: C.muted },

  voteBtn: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: C.surface, borderWidth: 1, borderColor: C.border,
    borderRadius: 8, padding: 14, marginBottom: 8,
  },
  voteBtnSelected: {
    borderColor: C.accent, backgroundColor: 'rgba(255,58,58,0.12)',
  },
  voteBtnText: { color: C.text, fontSize: 14 },
  voteCount: { fontSize: 11, color: C.accent },

  resultTop: { alignItems: 'center', paddingVertical: 16 },
  resultEmoji: { fontSize: 72, marginBottom: 12 },
  resultTitle: { fontSize: 44, fontWeight: '900', letterSpacing: 3 },
  resultSubtitle: { fontSize: 11, letterSpacing: 2, color: C.muted, marginTop: 6 },
  imposterName: { fontSize: 28, fontWeight: '900', letterSpacing: 3, color: C.accent },
  wordPair: { flexDirection: 'row', gap: 12, marginTop: 10, flexWrap: 'wrap' },
  wordPillCrew: {
    backgroundColor: 'rgba(0,229,160,0.15)', borderRadius: 20, paddingHorizontal: 14, paddingVertical: 6,
  },
  wordPillImp: {
    backgroundColor: 'rgba(255,58,58,0.15)', borderRadius: 20, paddingHorizontal: 14, paddingVertical: 6,
  },

  toast: {
    position: 'absolute', bottom: 30, left: 20, right: 20,
    backgroundColor: C.card, borderWidth: 1, borderRadius: 8,
    padding: 12, alignItems: 'center', zIndex: 999,
  },
  toastText: { fontSize: 13, letterSpacing: 1 },
});
